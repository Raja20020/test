Anonymice Powerline
===================

:Font creator: Mark Simonson
:Version: 1.002
:Source: http://www.marksimonson.com/fonts/view/anonymous-pro
:License: SIL OPEN FONT LICENSE Version 1.1
:Patched by: `Carl X. Su <https://github.com/bcbcarl>`_

Anonymous Pro (2009) is a family of four fixed-width fonts designed
especially with coding in mind. Characters that could be mistaken for
one another (O, 0, I, l, 1, etc.) have distinct shapes to make them
easier to tell apart in the context of source code.

Anonymice Powerline is derived from Anonymous Pro for Powerline users.
The Powerline symbols is being made by Kim Silkebækken. The patch work
is being undertaken by Carl X. Su.

Both the final font Truetype/OpenType files and the design files used
to produce the font family are distributed under an open licence and
you are expressly encouraged to experiment, modify, share and improve.